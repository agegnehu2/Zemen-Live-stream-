-- ============================================
-- STREAMING PLATFORM DATABASE SCHEMA
-- Full production-scale (DStv/YouTube Live style)
-- ============================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------- USERS ----------
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    avatar_url TEXT,
    bio TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_admin BOOLEAN DEFAULT FALSE,
    is_moderator BOOLEAN DEFAULT FALSE,
    is_banned BOOLEAN DEFAULT FALSE,
    ban_reason TEXT,
    date_of_birth DATE,                 -- required for age verification
    age_verified BOOLEAN DEFAULT FALSE,
    country VARCHAR(2),                 -- ISO country code
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- CHANNELS (a user or org can run a channel) ----------
CREATE TABLE channels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    banner_url TEXT,
    logo_url TEXT,
    category VARCHAR(50),               -- sports, news, entertainment, user, etc.
    is_verified BOOLEAN DEFAULT FALSE,
    subscriber_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- CATEGORIES ----------
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL
);

-- ---------- VIDEOS (VOD) ----------
CREATE TABLE videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    channel_id UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    playback_url TEXT,                  -- HLS/DASH manifest URL from CDN
    duration_seconds INT,
    category_id INT REFERENCES categories(id),
    visibility VARCHAR(20) DEFAULT 'public', -- public, unlisted, private
    status VARCHAR(20) DEFAULT 'processing', -- processing, ready, failed, removed
    age_restricted BOOLEAN DEFAULT FALSE,
    view_count BIGINT DEFAULT 0,
    like_count BIGINT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- LIVE STREAMS ----------
CREATE TABLE live_streams (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    channel_id UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    thumbnail_url TEXT,
    stream_key VARCHAR(100) UNIQUE NOT NULL,   -- for RTMP ingest auth
    playback_url TEXT,                          -- HLS output URL once live
    category_id INT REFERENCES categories(id),
    status VARCHAR(20) DEFAULT 'offline',       -- offline, live, ended
    age_restricted BOOLEAN DEFAULT FALSE,
    viewer_count INT DEFAULT 0,
    peak_viewer_count INT DEFAULT 0,
    started_at TIMESTAMPTZ,
    ended_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- SUBSCRIPTIONS (follow a channel) ----------
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    channel_id UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, channel_id)
);

-- ---------- LIVE CHAT MESSAGES ----------
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    live_stream_id UUID NOT NULL REFERENCES live_streams(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    is_deleted BOOLEAN DEFAULT FALSE,     -- soft delete for moderation
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- COMMENTS (on VOD videos) ----------
CREATE TABLE comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    parent_comment_id UUID REFERENCES comments(id),
    content TEXT NOT NULL,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- MODERATION REPORTS ----------
-- Every report is reviewed by a human moderator before action.
CREATE TABLE moderation_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reporter_id UUID NOT NULL REFERENCES users(id),
    target_type VARCHAR(20) NOT NULL,   -- video, live_stream, comment, chat_message, user
    target_id UUID NOT NULL,
    reason VARCHAR(50) NOT NULL,        -- sexual_content, violence, hate_speech, spam, other
    details TEXT,
    status VARCHAR(20) DEFAULT 'pending', -- pending, reviewed, action_taken, dismissed
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- CONTENT MODERATION FLAGS (automated scan results) ----------
CREATE TABLE content_flags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target_type VARCHAR(20) NOT NULL,   -- video, live_stream
    target_id UUID NOT NULL,
    flag_type VARCHAR(50) NOT NULL,     -- nudity, violence, copyrighted_audio, etc.
    confidence FLOAT,                   -- 0.0 - 1.0 from automated scanner
    auto_action VARCHAR(20),            -- none, blocked, age_restricted, under_review
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------- INDEXES ----------
CREATE INDEX idx_videos_channel ON videos(channel_id);
CREATE INDEX idx_videos_status ON videos(status);
CREATE INDEX idx_live_streams_status ON live_streams(status);
CREATE INDEX idx_chat_stream ON chat_messages(live_stream_id, created_at);
CREATE INDEX idx_comments_video ON comments(video_id);
CREATE INDEX idx_reports_status ON moderation_reports(status);
CREATE INDEX idx_flags_target ON content_flags(target_type, target_id);
